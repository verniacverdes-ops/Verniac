import React from 'react';
import {
  LayoutDashboard,
  FileText,
  Trash2,
  FolderKanban,
  Building2,
  Users2,
  Landmark,
  Layers,
  Archive as ArchiveIcon,
  Box,
  ClipboardList,
  Settings,
  X,
  Server,
  RefreshCcw,
  ShieldCheck,
  ClipboardCheck,
  DatabaseBackup,
} from 'lucide-react';
import { ApiConfig, MainViewTab } from '../types';

interface SidebarProps {
  activeTab: MainViewTab;
  onNavigateTab: (tab: MainViewTab) => void;
  totalArsip: number;
  totalSampah: number;
  pendingApproval: number;
  apiConfig: ApiConfig;
  canManageUsers: boolean;
  canManageSettings: boolean;
  onOpenUserManagementModal: () => void;
  onOpenUnitModal: () => void;
  onOpenBackendModal: () => void;
  isOpen: boolean;
  onClose: () => void;
}

interface NavItem {
  label: string;
  icon: React.ElementType;
  tab?: MainViewTab;
  onClick?: () => void;
  badge?: number;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onNavigateTab,
  totalArsip,
  totalSampah,
  pendingApproval,
  apiConfig,
  canManageUsers,
  canManageSettings,
  onOpenUserManagementModal,
  onOpenUnitModal,
  onOpenBackendModal,
  isOpen,
  onClose,
}) => {
  // Catatan arsitektur: mockup dashboard punya item sidebar terpisah untuk
  // Kategori/Unit/Gedung/Ruang/Rak/Dus, tapi di kode ini keenamnya sudah
  // digabung jadi dua view yang ada (MasterDataView untuk Kategori/Unit/Dus,
  // LocationHierarchyView untuk Gedung/Ruang/Rak) -- bukan 6 tab terpisah.
  // Daripada memecah ulang arsitektur view yang sudah berjalan, item di
  // bawah ini diarahkan ke view yang sudah tepat; label tetap sesuai mockup.
  const sections: NavSection[] = [
    {
      title: 'Menu Utama',
      items: [
        { label: 'Dashboard', icon: LayoutDashboard, tab: 'dashboard' },
        { label: 'Arsip', icon: FileText, tab: 'arsip', badge: totalArsip },
        { label: 'Recycle Bin', icon: Trash2, tab: 'recycle_bin', badge: totalSampah },
      ],
    },
    {
      title: 'Master Data',
      items: [
        { label: 'Kategori', icon: FolderKanban, tab: 'master' },
        { label: 'Unit', icon: Building2, tab: 'master' },
        { label: 'Gedung', icon: Landmark, tab: 'hirarki_lokasi' },
        { label: 'Ruang', icon: Layers, tab: 'hirarki_lokasi' },
        { label: 'Rak', icon: ArchiveIcon, tab: 'hirarki_lokasi' },
        { label: 'Dus', icon: Box, tab: 'master' },
      ],
    },
    {
      title: 'Operasional',
      items: [
        { label: 'Sirkulasi Pinjam', icon: RefreshCcw, tab: 'sirkulasi' },
        { label: 'Retensi & Musnah', icon: ShieldCheck, tab: 'retensi_pemusnahan' },
        { label: 'Persetujuan', icon: ClipboardCheck, tab: 'approval', badge: pendingApproval },
        { label: 'Laporan', icon: ClipboardList, tab: 'laporan' },
        { label: 'Backup / Restore', icon: DatabaseBackup, tab: 'backup_restore' },
      ],
    },
    {
      title: 'Sistem',
      items: [
        { label: 'Audit Log', icon: ClipboardList, tab: 'audit_log' },
        ...(canManageUsers
          ? [{ label: 'Pengguna', icon: Users2, onClick: onOpenUserManagementModal }]
          : []),
        ...(canManageSettings
          ? [{ label: 'Pengaturan', icon: Settings, onClick: onOpenUnitModal }]
          : []),
      ],
    },
  ];

  const handleNavClick = (item: NavItem) => {
    if (item.tab) onNavigateTab(item.tab);
    else if (item.onClick) item.onClick();
    onClose();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed lg:sticky top-0 left-0 h-screen w-64 bg-slate-900 text-slate-300 flex flex-col z-50 shrink-0 transition-transform duration-200 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0`}
      >
        {/* Logo */}
        <div className="h-16 px-5 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-blue-600 flex items-center justify-center shrink-0">
              <ArchiveIcon className="w-4.5 h-4.5 text-white" />
            </div>
            <span className="font-black text-white text-sm tracking-tight">Pertelaan Arsip</span>
          </div>
          <button onClick={onClose} className="lg:hidden text-slate-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-5">
          {sections.map((section) => (
            <div key={section.title} className="space-y-1">
              <h4 className="px-2.5 mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                {section.title}
              </h4>
              {section.items.map((item) => {
                const Icon = item.icon;
                const active = item.tab && item.tab === activeTab;
                return (
                  <button
                    key={item.label}
                    onClick={() => handleNavClick(item)}
                    className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                      active
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <span className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4 shrink-0" />
                      <span>{item.label}</span>
                    </span>
                    {!!item.badge && item.badge > 0 && (
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center ${
                          active ? 'bg-white/20 text-white' : 'bg-slate-700 text-slate-200'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        {/* Footer: status koneksi backend */}
        <button
          onClick={onOpenBackendModal}
          className="shrink-0 border-t border-slate-800 px-4 py-3 flex items-center justify-between text-xs hover:bg-slate-800/60 transition-colors cursor-pointer"
        >
          <span className="flex items-center gap-2 text-slate-400">
            <span
              className={`w-2 h-2 rounded-full ${apiConfig.useLaravelApi ? 'bg-emerald-500' : 'bg-slate-600'}`}
            />
            <span>{apiConfig.useLaravelApi ? 'Online' : 'Mode Lokal'}</span>
          </span>
          <span className="flex items-center gap-1 text-slate-600">
            <Server className="w-3 h-3" />
            <span>v1.0 · 2026</span>
          </span>
        </button>
      </aside>
    </>
  );
};
