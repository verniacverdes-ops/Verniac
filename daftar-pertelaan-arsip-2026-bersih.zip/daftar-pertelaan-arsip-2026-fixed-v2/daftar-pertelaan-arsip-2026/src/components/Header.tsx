import React from 'react';
import { Archive, Plus, Printer, FileSpreadsheet, Settings, FileText, Box, MapPin, UserCheck, Server, Shield, LogIn } from 'lucide-react';
import { UnitInfo, User, ApiConfig } from '../types';
import { hasRolePermission } from '../lib/permissions';

interface HeaderProps {
  unitInfo: UnitInfo;
  currentUser: User | null;
  apiConfig: ApiConfig;
  totalItems: number;
  totalDus: number;
  totalLocations: number;
  onOpenAddModal: () => void;
  onOpenPrintModal: () => void;
  onOpenExportModal: () => void;
  onOpenUnitModal: () => void;
  onOpenLoginModal: () => void;
  onOpenBackendModal: () => void;
  onOpenUserManagementModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  unitInfo,
  currentUser,
  apiConfig,
  totalItems,
  totalDus,
  totalLocations,
  onOpenAddModal,
  onOpenPrintModal,
  onOpenExportModal,
  onOpenUnitModal,
  onOpenLoginModal,
  onOpenBackendModal,
  onOpenUserManagementModal,
}) => {
  const canAdd = hasRolePermission(currentUser?.role, 'tambah');
  // Dua tombol berbeda sengaja dipisah jadi dua variabel, bukan dipaksa
  // satu `isAdmin` seperti sebelumnya:
  //   - canManageUsers -> tombol "Manajemen Hak Akses (RBAC)", HARUS
  //     mengikuti PERMISSION_MATRIX.manageUser (hanya super_admin).
  //   - canManageSettings -> tombol "Pengaturan Instansi", tidak punya
  //     key permission khusus di matriks, jadi tetap dibuka untuk admin
  //     & super_admin seperti perilaku sebelumnya (memakainya untuk
  //     manageUser akan diam-diam mencabut akses admin ke menu ini).
  const canManageUsers = hasRolePermission(currentUser?.role, 'manageUser');
  const canManageSettings = currentUser?.role === 'admin' || currentUser?.role === 'super_admin';

  return (
    <header className="bg-slate-900 text-white shadow-md border-b border-slate-800">
      
      {/* Top Access Bar for Tahap 1 Fondasi */}
      <div className="bg-slate-950 border-b border-slate-800/80 px-4 sm:px-6 lg:px-8 py-1.5 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-2">
          
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenBackendModal}
              className="inline-flex items-center gap-1.5 text-slate-300 hover:text-emerald-400 transition-colors font-medium cursor-pointer"
            >
              <Server className="w-3.5 h-3.5 text-emerald-500" />
              <span>Tahap 1 Fondasi:</span>
              <span className={`font-mono font-bold px-1.5 py-0.2 rounded text-[10px] ${apiConfig.useLaravelApi ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-800 text-slate-300'}`}>
                {apiConfig.useLaravelApi ? 'Laravel API Active' : 'MySQL & Laravel Ready'}
              </span>
            </button>

            {canManageUsers && (
              <button
                onClick={onOpenUserManagementModal}
                className="inline-flex items-center gap-1 text-purple-400 hover:text-purple-300 transition-colors font-semibold cursor-pointer border-l border-slate-800 pl-3"
              >
                <Shield className="w-3.5 h-3.5" />
                <span>Manajemen Hak Akses (RBAC)</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {currentUser ? (
              <button
                onClick={onOpenLoginModal}
                className="flex items-center gap-2 hover:bg-slate-800 px-2 py-0.5 rounded transition-all cursor-pointer"
              >
                <img
                  src={currentUser.avatarUrl}
                  alt={currentUser.name}
                  className="w-5 h-5 rounded-full object-cover border border-slate-600"
                />
                <span className="font-bold text-slate-200">{currentUser.name}</span>
                <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase border ${
                  currentUser.role === 'admin'
                    ? 'bg-purple-900/60 text-purple-300 border-purple-500/30'
                    : currentUser.role === 'arsiparis'
                    ? 'bg-blue-900/60 text-blue-300 border-blue-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}>
                  {currentUser.role}
                </span>
              </button>
            ) : (
              <button
                onClick={onOpenLoginModal}
                className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded transition-all cursor-pointer text-[11px]"
              >
                <LogIn className="w-3 h-3" />
                <span>Login Pengguna</span>
              </button>
            )}
          </div>

        </div>
      </div>

      {/* Main Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          
          {/* Title and Identity */}
          <div className="flex items-start gap-3">
            <div className="p-3 bg-blue-600/20 text-blue-400 rounded-xl border border-blue-500/30 shrink-0 mt-1">
              <Archive className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-semibold uppercase tracking-wider bg-blue-500/20 text-blue-300 px-2.5 py-0.5 rounded-full border border-blue-500/30">
                  Arsip Inaktif / Statis
                </span>
                <span className="text-xs font-semibold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                  Tahun {unitInfo.tahun}
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-1">
                DAFTAR PERTELAAN ARSIP TAHUN {unitInfo.tahun}
              </h1>
              <p className="text-sm text-slate-400 mt-1 flex items-center gap-2 flex-wrap">
                <span className="font-medium text-slate-300">{unitInfo.namaInstansi}</span>
                <span className="text-slate-600">•</span>
                <span>{unitInfo.unitKerja}</span>
              </p>
            </div>
          </div>

          {/* Header Action Buttons */}
          <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
            {canAdd && (
              <button
                onClick={onOpenAddModal}
                id="btn-tambah-arsip"
                className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-medium px-4 py-2.5 rounded-lg shadow-sm transition-all focus:ring-2 focus:ring-blue-400 focus:outline-none cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Tambah Data Arsip</span>
              </button>
            )}

            <button
              onClick={onOpenPrintModal}
              id="btn-cetak-daftar"
              className="inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium px-3.5 py-2.5 rounded-lg transition-all focus:ring-2 focus:ring-slate-500 cursor-pointer"
              title="Cetak/Print Format Resmi"
            >
              <Printer className="w-4 h-4 text-emerald-400" />
              <span className="hidden sm:inline">Cetak Dokumen</span>
            </button>

            <button
              onClick={onOpenExportModal}
              id="btn-ekspor-impor"
              className="inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium px-3.5 py-2.5 rounded-lg transition-all focus:ring-2 focus:ring-slate-500 cursor-pointer"
              title="Ekspor/Impor CSV/JSON"
            >
              <FileSpreadsheet className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">Ekspor / Impor</span>
            </button>

            {canManageSettings && (
              <button
                onClick={onOpenUnitModal}
                id="btn-pengaturan-instansi"
                className="inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-medium px-3 py-2.5 rounded-lg transition-all cursor-pointer"
                title="Atur Data Instansi & Tanda Tangan"
              >
                <Settings className="w-4 h-4 text-slate-400" />
              </button>
            )}
          </div>
        </div>

        {/* Quick Stats Counter Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-5 pt-4 border-t border-slate-800/80">
          <div className="flex items-center gap-3 bg-slate-800/50 rounded-lg p-2.5 border border-slate-800">
            <div className="p-2 bg-blue-500/10 text-blue-400 rounded-md">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs text-slate-400">Total Berkas / Dokumen</p>
              <p className="text-lg font-bold text-white">{totalItems} <span className="text-xs font-normal text-slate-400">Arsip</span></p>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-slate-800/50 rounded-lg p-2.5 border border-slate-800">
            <div className="p-2 bg-amber-500/10 text-amber-400 rounded-md">
              <Box className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs text-slate-400">Total Boks / No. Dus</p>
              <p className="text-lg font-bold text-white">{totalDus} <span className="text-xs font-normal text-slate-400">Dus Terdaftar</span></p>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-slate-800/50 rounded-lg p-2.5 border border-slate-800">
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-md">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs text-slate-400">Titik Lokasi Depo</p>
              <p className="text-lg font-bold text-white">{totalLocations} <span className="text-xs font-normal text-slate-400">Lokasi</span></p>
            </div>
          </div>
        </div>

      </div>
    </header>
  );
};

