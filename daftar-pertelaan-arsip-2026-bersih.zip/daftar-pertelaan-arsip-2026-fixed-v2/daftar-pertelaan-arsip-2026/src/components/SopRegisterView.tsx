import React, { useState, useEffect } from 'react';
import {
  Plus,
  Trash2,
  Save,
  FileText,
  Upload,
  Link2,
  ChevronDown,
  ChevronRight,
  ClipboardList,
} from 'lucide-react';

// =====================================================================
// SopRegisterView.tsx
// "REGISTER SOP KEPALA BADAN TAHUN 2025" — tabel terpisah/berdiri
// sendiri sesuai permintaan (bukan bagian dari tabel Arsip yang sudah
// ada). Dibuat mandiri (tidak mengimpor ../types atau ../lib/permissions)
// karena kedua file itu tidak ada di dalam paket proyek yang diunggah,
// jadi komponen ini bisa langsung ditempel tanpa menunggu file lain.
//
// Cara pasang ke App.tsx Anda (3 langkah):
//   1) import { SopRegisterView } from './components/SopRegisterView';
//   2) Tambahkan 'sop-register' ke union type MainViewTab di types.ts
//   3) Render <SopRegisterView /> saat activeTab === 'sop-register',
//      dan tambahkan menu "Register SOP" di Sidebar.tsx (lihat contoh
//      di bagian bawah file ini / pesan chat).
// =====================================================================

interface SopRow {
  id: string;
  no: string; // biasanya angka urut, tapi dibuat teks agar bisa "1", "1a", dst.
  noKeputusan: string;
  tentang: string;
  fileName: string; // nama file yang diupload
  fileUrl: string; // data URL (base64) hasil upload, atau link manual
  keterangan: string;
}

interface SopSection {
  id: string;
  kode: string; // A, B, C, D, E ...
  judul: string;
  rows: SopRow[];
}

const STORAGE_KEY = 'sop_register_kepala_badan_2025_v1';

const uid = () => Math.random().toString(36).slice(2, 10);

const emptyRow = (no: string): SopRow => ({
  id: uid(),
  no,
  noKeputusan: '',
  tentang: '',
  fileName: '',
  fileUrl: '',
  keterangan: '',
});

// Struktur awal persis sesuai foto register yang diberikan.
// Jumlah baris kosong per bagian mengikuti jumlah baris pada foto,
// silakan tambah/kurangi lewat tombol "Tambah Baris" di tiap bagian.
const buildInitialSections = (): SopSection[] => [
  {
    id: uid(),
    kode: 'A',
    judul: 'SOP SEKRETARIAT',
    rows: Array.from({ length: 6 }, (_, i) => emptyRow(String(i + 1))),
  },
  {
    id: uid(),
    kode: 'B',
    judul: 'SOP BIDANG PERENCANAAN DAN PENGEMBANGAN',
    rows: Array.from({ length: 5 }, (_, i) => emptyRow(String(i + 1))),
  },
  {
    id: uid(),
    kode: 'C',
    judul: 'SOP BIDANG PENDATAAN DAN PENILAIAN',
    rows: Array.from({ length: 6 }, (_, i) => emptyRow(String(i + 1))),
  },
  {
    id: uid(),
    kode: 'D',
    judul: 'SOP BIDANG PELAYANAN DAN PENETAPAN',
    rows: Array.from({ length: 4 }, (_, i) => emptyRow(String(i + 1))),
  },
  {
    id: uid(),
    kode: 'E',
    judul: 'SOP BIDANG PENAGIHAN, KEBERATAN DAN PENGAWASAN PENDAPATAN DAERAH',
    rows: Array.from({ length: 5 }, (_, i) => emptyRow(String(i + 1))),
  },
];

export const SopRegisterView: React.FC = () => {
  const [sections, setSections] = useState<SopSection[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      /* ignore corrupt storage */
    }
    return buildInitialSections();
  });
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const [savedFlash, setSavedFlash] = useState(false);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sections));
    setSavedFlash(true);
    const t = setTimeout(() => setSavedFlash(false), 900);
    return () => clearTimeout(t);
  }, [sections]);

  const updateRow = (sectionId: string, rowId: string, field: keyof SopRow, value: string) => {
    setSections(prev =>
      prev.map(sec =>
        sec.id !== sectionId
          ? sec
          : { ...sec, rows: sec.rows.map(r => (r.id === rowId ? { ...r, [field]: value } : r)) }
      )
    );
  };

  const addRow = (sectionId: string) => {
    setSections(prev =>
      prev.map(sec =>
        sec.id !== sectionId ? sec : { ...sec, rows: [...sec.rows, emptyRow(String(sec.rows.length + 1))] }
      )
    );
  };

  const deleteRow = (sectionId: string, rowId: string) => {
    setSections(prev =>
      prev.map(sec => (sec.id !== sectionId ? sec : { ...sec, rows: sec.rows.filter(r => r.id !== rowId) }))
    );
  };

  const addSection = () => {
    const nextKode = String.fromCharCode('A'.charCodeAt(0) + sections.length);
    setSections(prev => [
      ...prev,
      { id: uid(), kode: nextKode, judul: 'BAGIAN BARU', rows: [emptyRow('1')] },
    ]);
  };

  const deleteSection = (sectionId: string) => {
    if (!confirm('Hapus seluruh bagian ini beserta isinya?')) return;
    setSections(prev => prev.filter(sec => sec.id !== sectionId));
  };

  const renameSection = (sectionId: string, judul: string) => {
    setSections(prev => prev.map(sec => (sec.id === sectionId ? { ...sec, judul } : sec)));
  };

  const toggleCollapse = (sectionId: string) => {
    setCollapsed(prev => ({ ...prev, [sectionId]: !prev[sectionId] }));
  };

  const handleFileUpload = (sectionId: string, rowId: string, file: File | null) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      updateRow(sectionId, rowId, 'fileName', file.name);
      updateRow(sectionId, rowId, 'fileUrl', String(reader.result || ''));
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="p-4 md:p-6 space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-indigo-100 flex items-center justify-center">
            <ClipboardList className="w-5 h-5 text-indigo-600" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-slate-800">Register SOP Kepala Badan Tahun 2025</h1>
            <p className="text-xs text-slate-500">
              Tabel terpisah dari daftar arsip — untuk mencatat SOP per bidang beserta file keputusannya.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span
            className={`text-xs px-2 py-1 rounded-full transition-opacity ${
              savedFlash ? 'opacity-100 bg-green-100 text-green-700' : 'opacity-0'
            }`}
          >
            Tersimpan
          </span>
          <button
            onClick={addSection}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition-colors"
          >
            <Plus className="w-4 h-4" /> Tambah Bagian
          </button>
        </div>
      </div>

      {/* Sections */}
      <div className="space-y-4">
        {sections.map(section => {
          const isCollapsed = !!collapsed[section.id];
          return (
            <div key={section.id} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              {/* Section header */}
              <div className="flex items-center gap-2 px-4 py-3 bg-slate-50 border-b border-slate-200">
                <button
                  onClick={() => toggleCollapse(section.id)}
                  className="p-1 rounded hover:bg-slate-200 text-slate-500"
                  title={isCollapsed ? 'Buka' : 'Tutup'}
                >
                  {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
                <span className="flex items-center justify-center w-6 h-6 rounded bg-indigo-600 text-white text-xs font-bold shrink-0">
                  {section.kode}
                </span>
                <input
                  value={section.judul}
                  onChange={e => renameSection(section.id, e.target.value)}
                  className="flex-1 bg-transparent font-semibold text-sm text-slate-800 uppercase tracking-wide outline-none focus:bg-white focus:ring-1 focus:ring-indigo-300 rounded px-1 py-0.5"
                />
                <span className="text-xs text-slate-400">{section.rows.length} baris</span>
                <button
                  onClick={() => deleteSection(section.id)}
                  className="p-1.5 rounded hover:bg-red-50 text-slate-400 hover:text-red-600"
                  title="Hapus bagian"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Table */}
              {!isCollapsed && (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm border-collapse">
                    <thead>
                      <tr className="bg-slate-100 text-slate-600 text-xs uppercase tracking-wide">
                        <th className="px-3 py-2 text-left border-b border-slate-200 w-14">No</th>
                        <th className="px-3 py-2 text-left border-b border-slate-200 w-48">No. Keputusan</th>
                        <th className="px-3 py-2 text-left border-b border-slate-200">Tentang</th>
                        <th className="px-3 py-2 text-left border-b border-slate-200 w-56">File</th>
                        <th className="px-3 py-2 text-left border-b border-slate-200 w-56">Keterangan</th>
                        <th className="px-2 py-2 border-b border-slate-200 w-10" />
                      </tr>
                    </thead>
                    <tbody>
                      {section.rows.map(row => (
                        <tr key={row.id} className="border-b border-slate-100 hover:bg-slate-50/60">
                          <td className="px-3 py-1.5 align-top">
                            <input
                              value={row.no}
                              onChange={e => updateRow(section.id, row.id, 'no', e.target.value)}
                              className="w-full bg-transparent outline-none focus:ring-1 focus:ring-indigo-300 rounded px-1 py-1 text-center"
                            />
                          </td>
                          <td className="px-3 py-1.5 align-top">
                            <input
                              value={row.noKeputusan}
                              onChange={e => updateRow(section.id, row.id, 'noKeputusan', e.target.value)}
                              placeholder="mis. 188/45-BPPRD/2025"
                              className="w-full bg-transparent outline-none focus:ring-1 focus:ring-indigo-300 rounded px-1 py-1"
                            />
                          </td>
                          <td className="px-3 py-1.5 align-top">
                            <textarea
                              value={row.tentang}
                              onChange={e => updateRow(section.id, row.id, 'tentang', e.target.value)}
                              placeholder="Perihal / judul SOP"
                              rows={1}
                              className="w-full bg-transparent outline-none focus:ring-1 focus:ring-indigo-300 rounded px-1 py-1 resize-y"
                            />
                          </td>
                          <td className="px-3 py-1.5 align-top">
                            {row.fileUrl ? (
                              <a
                                href={row.fileUrl}
                                download={row.fileName}
                                className="inline-flex items-center gap-1.5 text-indigo-600 hover:underline text-xs"
                              >
                                <FileText className="w-3.5 h-3.5" />
                                <span className="truncate max-w-[9rem]">{row.fileName}</span>
                              </a>
                            ) : (
                              <label className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-indigo-600 cursor-pointer">
                                <Upload className="w-3.5 h-3.5" />
                                Unggah file
                                <input
                                  type="file"
                                  className="hidden"
                                  onChange={e => handleFileUpload(section.id, row.id, e.target.files?.[0] || null)}
                                />
                              </label>
                            )}
                            {row.fileUrl && (
                              <button
                                onClick={() => {
                                  updateRow(section.id, row.id, 'fileName', '');
                                  updateRow(section.id, row.id, 'fileUrl', '');
                                }}
                                className="ml-2 text-[10px] text-slate-400 hover:text-red-600"
                              >
                                ganti
                              </button>
                            )}
                          </td>
                          <td className="px-3 py-1.5 align-top">
                            <input
                              value={row.keterangan}
                              onChange={e => updateRow(section.id, row.id, 'keterangan', e.target.value)}
                              className="w-full bg-transparent outline-none focus:ring-1 focus:ring-indigo-300 rounded px-1 py-1"
                            />
                          </td>
                          <td className="px-2 py-1.5 align-top text-center">
                            <button
                              onClick={() => deleteRow(section.id, row.id)}
                              className="p-1 rounded hover:bg-red-50 text-slate-300 hover:text-red-600"
                              title="Hapus baris"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <div className="px-4 py-2 bg-slate-50/60">
                    <button
                      onClick={() => addRow(section.id)}
                      className="inline-flex items-center gap-1.5 text-xs font-medium text-indigo-600 hover:text-indigo-800"
                    >
                      <Plus className="w-3.5 h-3.5" /> Tambah Baris
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <p className="text-xs text-slate-400 flex items-center gap-1.5 pt-2">
        <Save className="w-3.5 h-3.5" /> Data tersimpan otomatis di penyimpanan lokal browser (localStorage).
      </p>
    </div>
  );
};
