import React, { useState } from 'react';
import { Menu, Search, Bell, HelpCircle, ChevronDown, Printer, FileSpreadsheet, Users2, LogOut, LogIn } from 'lucide-react';
import { User } from '../types';

interface TopHeaderProps {
  currentUser: User | null;
  pendingApprovalCount: number;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenMobileSidebar: () => void;
  onOpenPrintModal: () => void;
  onOpenExportModal: () => void;
  onOpenLoginModal: () => void;
  onLogout: () => void;
  canManageUsers: boolean;
  onOpenUserManagementModal: () => void;
}

const ROLE_LABELS: Record<string, string> = {
  super_admin: 'Super Administrator',
  admin: 'Administrator',
  arsiparis: 'Arsiparis',
  operator: 'Operator Arsip',
  viewer: 'Viewer',
  auditor: 'Auditor',
};

export const TopHeader: React.FC<TopHeaderProps> = ({
  currentUser,
  pendingApprovalCount,
  searchQuery,
  onSearchChange,
  onOpenMobileSidebar,
  onOpenPrintModal,
  onOpenExportModal,
  onOpenLoginModal,
  onLogout,
  canManageUsers,
  onOpenUserManagementModal,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const initials = currentUser?.name
    ? currentUser.name
        .split(' ')
        .filter(Boolean)
        .slice(0, 2)
        .map((w) => w[0])
        .join('')
        .toUpperCase()
    : '?';

  return (
    <header className="h-16 bg-white border-b border-slate-200 shrink-0 px-4 sm:px-6 flex items-center justify-between gap-3 relative z-30">
      <div className="flex items-center gap-3 flex-1 min-w-0">
        <button
          onClick={onOpenMobileSidebar}
          className="lg:hidden text-slate-500 hover:text-slate-900 cursor-pointer shrink-0"
        >
          <Menu className="w-5.5 h-5.5" />
        </button>

        <div className="relative w-full max-w-xs hidden sm:block">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Cari arsip..."
            className="w-full pl-9 pr-3 py-2 bg-slate-100 border border-transparent rounded-lg text-sm focus:bg-white focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
          />
        </div>
      </div>

      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
        <button
          onClick={onOpenPrintModal}
          title="Cetak Dokumen"
          className="hidden md:flex p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg cursor-pointer transition-colors"
        >
          <Printer className="w-4.5 h-4.5" />
        </button>
        <button
          onClick={onOpenExportModal}
          title="Ekspor / Impor"
          className="hidden md:flex p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg cursor-pointer transition-colors"
        >
          <FileSpreadsheet className="w-4.5 h-4.5" />
        </button>

        <button
          title={pendingApprovalCount > 0 ? `${pendingApprovalCount} persetujuan menunggu` : 'Tidak ada notifikasi baru'}
          className="relative p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg cursor-pointer transition-colors"
        >
          <Bell className="w-4.5 h-4.5" />
          {pendingApprovalCount > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 bg-rose-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
              {pendingApprovalCount > 9 ? '9+' : pendingApprovalCount}
            </span>
          )}
        </button>

        <button
          title="Bantuan"
          className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg cursor-pointer transition-colors"
        >
          <HelpCircle className="w-4.5 h-4.5" />
        </button>

        <div className="w-px h-6 bg-slate-200 mx-1 hidden sm:block" />

        {currentUser ? (
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen((v) => !v)}
              className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-lg hover:bg-slate-100 cursor-pointer transition-colors"
            >
              {currentUser.avatarUrl ? (
                <img
                  src={currentUser.avatarUrl}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-full object-cover border border-slate-200"
                />
              ) : (
                <span className="w-8 h-8 rounded-full bg-slate-800 text-white text-xs font-bold flex items-center justify-center">
                  {initials}
                </span>
              )}
              <span className="hidden sm:block text-left leading-tight">
                <span className="block text-xs font-bold text-slate-900">{currentUser.name}</span>
                <span className="block text-[10px] text-slate-500">{ROLE_LABELS[currentUser.role] || currentUser.role}</span>
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
            </button>

            {isMenuOpen && (
              <>
                <div className="fixed inset-0 z-30" onClick={() => setIsMenuOpen(false)} />
                <div className="absolute right-0 mt-2 w-56 bg-white border border-slate-200 rounded-xl shadow-lg py-1.5 z-40">
                  <div className="px-3.5 py-2 border-b border-slate-100">
                    <p className="text-xs font-bold text-slate-900">{currentUser.name}</p>
                    <p className="text-[11px] text-slate-500">{currentUser.email}</p>
                  </div>
                  {canManageUsers && (
                    <button
                      onClick={() => { setIsMenuOpen(false); onOpenUserManagementModal(); }}
                      className="w-full px-3.5 py-2 flex items-center gap-2 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                    >
                      <Users2 className="w-3.5 h-3.5 text-slate-400" />
                      <span>Manajemen Pengguna</span>
                    </button>
                  )}
                  <button
                    onClick={() => { setIsMenuOpen(false); onLogout(); }}
                    className="w-full px-3.5 py-2 flex items-center gap-2 text-xs font-medium text-rose-600 hover:bg-rose-50 cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Keluar</span>
                  </button>
                </div>
              </>
            )}
          </div>
        ) : (
          <button
            onClick={onOpenLoginModal}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg cursor-pointer transition-colors"
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Masuk</span>
          </button>
        )}
      </div>
    </header>
  );
};
