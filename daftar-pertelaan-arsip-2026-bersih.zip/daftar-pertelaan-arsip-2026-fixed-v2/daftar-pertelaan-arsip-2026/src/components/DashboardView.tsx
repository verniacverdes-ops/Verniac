import React, { useMemo, useState } from 'react';
import {
  ArchiveItem,
  AuditLogEntry,
  MasterDus,
  MasterGedung,
  MasterKategori,
  MasterUnit,
  User,
} from '../types';
import {
  FileText,
  Building2,
  FolderKanban,
  Trash2,
  Plus,
  ArrowRight,
  ArrowUpRight,
  ArrowDownRight,
  FilePlus2,
  Pencil,
  RotateCcw,
  DatabaseBackup,
  LogIn,
  LogOut,
  Clock,
  QrCode,
} from 'lucide-react';
import { timeAgo } from '../lib/dateUtils';

interface DashboardViewProps {
  items: ArchiveItem[];
  deletedCount: number;
  auditLogs: AuditLogEntry[];
  masterDusList: MasterDus[];
  masterGedungList: MasterGedung[];
  masterKategoriList: MasterKategori[];
  masterUnitList: MasterUnit[];
  currentUser?: User | null;
  canAdd?: boolean;
  onOpenAddModal?: () => void;
  onNavigateToArsipWithFilter: (dusFilter?: string, kategoriFilter?: string) => void;
  onNavigateTab: (tab: 'arsip' | 'master' | 'hirarki_lokasi' | 'qr_scanner' | 'sirkulasi' | 'retensi_pemusnahan' | 'recycle_bin' | 'audit_log') => void;
  onOpenPdfModal: (item: ArchiveItem) => void;
  onOpenQrModal: (item: ArchiveItem) => void;
}

const DONUT_COLORS = ['#2563eb', '#0ea5e9', '#10b981', '#f59e0b', '#8b5cf6', '#64748b'];

const ACTION_META: Record<
  AuditLogEntry['action'],
  { icon: React.ElementType; bg: string; fg: string; label: string }
> = {
  TAMBAH: { icon: FilePlus2, bg: 'bg-emerald-100', fg: 'text-emerald-700', label: 'menambah arsip baru' },
  UBAH: { icon: Pencil, bg: 'bg-blue-100', fg: 'text-blue-700', label: 'memperbarui arsip' },
  SOFT_DELETE: { icon: Trash2, bg: 'bg-amber-100', fg: 'text-amber-700', label: 'memindahkan arsip ke recycle bin' },
  PULIHKAN: { icon: RotateCcw, bg: 'bg-sky-100', fg: 'text-sky-700', label: 'memulihkan arsip' },
  HAPUS_PERMANEN: { icon: Trash2, bg: 'bg-rose-100', fg: 'text-rose-700', label: 'menghapus arsip permanen' },
  BACKUP: { icon: DatabaseBackup, bg: 'bg-purple-100', fg: 'text-purple-700', label: 'membuat backup data' },
  RESTORE: { icon: RotateCcw, bg: 'bg-purple-100', fg: 'text-purple-700', label: 'memulihkan dari backup' },
  LOGIN: { icon: LogIn, bg: 'bg-slate-200', fg: 'text-slate-700', label: 'masuk ke sistem' },
  LOGOUT: { icon: LogOut, bg: 'bg-slate-200', fg: 'text-slate-700', label: 'keluar dari sistem' },
};

const PERIOD_OPTIONS = [
  { value: 7, label: '7 Hari Terakhir' },
  { value: 30, label: '30 Hari Terakhir' },
  { value: 90, label: '90 Hari Terakhir' },
  { value: 0, label: 'Semua Waktu' },
];

const MONTH_LABELS = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

export const DashboardView: React.FC<DashboardViewProps> = ({
  items,
  deletedCount,
  auditLogs,
  masterKategoriList,
  masterUnitList,
  currentUser,
  canAdd,
  onOpenAddModal,
  onNavigateToArsipWithFilter,
  onNavigateTab,
  onOpenPdfModal,
  onOpenQrModal,
}) => {
  const [categoryPeriodDays, setCategoryPeriodDays] = useState(30);

  const totalItems = items.length;
  const monthGrowthPct = useMemo(() => {
    const now = new Date();
    const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    let thisMonth = 0;
    let lastMonth = 0;
    items.forEach((item) => {
      const d = new Date(item.createdAt);
      if (isNaN(d.getTime())) return;
      if (d >= thisMonthStart) thisMonth++;
      else if (d >= lastMonthStart && d < thisMonthStart) lastMonth++;
    });
    if (lastMonth === 0) return thisMonth > 0 ? 100 : 0;
    return Math.round(((thisMonth - lastMonth) / lastMonth) * 100);
  }, [items]);

  const totalUnit = masterUnitList.length;
  const totalKategori = masterKategoriList.length;

  const categoryBreakdown = useMemo(() => {
    const cutoff = categoryPeriodDays > 0 ? Date.now() - categoryPeriodDays * 24 * 60 * 60 * 1000 : null;
    const counts: Record<string, number> = {};
    items.forEach((item) => {
      if (cutoff !== null) {
        const d = new Date(item.tanggal);
        if (isNaN(d.getTime()) || d.getTime() < cutoff) return;
      }
      const kat = item.kategoriArsip || 'Lainnya';
      counts[kat] = (counts[kat] || 0) + 1;
    });
    const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    const top = entries.slice(0, 5);
    const rest = entries.slice(5).reduce((sum, [, v]) => sum + v, 0);
    if (rest > 0) top.push(['Lainnya', rest]);
    const total = top.reduce((sum, [, v]) => sum + v, 0);
    return top.map(([name, count], idx) => ({
      name,
      count,
      pct: total > 0 ? Math.round((count / total) * 1000) / 10 : 0,
      color: DONUT_COLORS[idx % DONUT_COLORS.length],
    }));
  }, [items, categoryPeriodDays]);

  const categoryTotal = categoryBreakdown.reduce((s, c) => s + c.count, 0);
  const donutRadius = 70;
  const donutCircumference = 2 * Math.PI * donutRadius;
  let cumulativePct = 0;
  const donutSegments = categoryBreakdown.map((c) => {
    const dash = (c.pct / 100) * donutCircumference;
    const offset = -((cumulativePct / 100) * donutCircumference);
    cumulativePct += c.pct;
    return { ...c, dash, offset };
  });

  const availableYears = useMemo(() => {
    const years = new Set<number>();
    items.forEach((item) => {
      const y = new Date(item.tanggal).getFullYear();
      if (!isNaN(y)) years.add(y);
    });
    years.add(new Date().getFullYear());
    return Array.from(years).sort((a, b) => b - a);
  }, [items]);

  const [selectedYear, setSelectedYear] = useState(availableYears[0]);

  const monthlyBreakdown = useMemo(() => {
    const counts = new Array(12).fill(0);
    items.forEach((item) => {
      const d = new Date(item.tanggal);
      if (isNaN(d.getTime()) || d.getFullYear() !== selectedYear) return;
      counts[d.getMonth()]++;
    });
    return counts;
  }, [items, selectedYear]);

  const monthlyMax = Math.max(1, ...monthlyBreakdown);

  const recentItems = useMemo(
    () => [...items].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 5),
    [items]
  );

  const recentActivity = useMemo(
    () => [...auditLogs].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 6),
    [auditLogs]
  );

  const greetingName = currentUser?.name?.split(' ')[0] || currentUser?.name || 'Pengguna';

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900">Selamat datang, {greetingName}!</h1>
          <p className="text-sm text-slate-500 mt-0.5">Kelola pertelaan arsip dengan mudah dan efisien</p>
        </div>
        {canAdd && onOpenAddModal && (
          <button
            onClick={onOpenAddModal}
            className="inline-flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white text-sm font-bold px-4 py-2.5 rounded-xl shadow-sm transition-all cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Arsip Baru</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div onClick={() => onNavigateToArsipWithFilter('ALL')} className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs hover:shadow-md transition-all cursor-pointer group">
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl w-fit"><FileText className="w-5 h-5" /></div>
          <p className="mt-3 text-xs font-medium text-slate-500">Total Arsip</p>
          <p className="text-3xl font-black text-slate-900">{totalItems.toLocaleString('id-ID')}</p>
          <div className="mt-1 flex items-center gap-1 text-xs font-bold">
            {monthGrowthPct >= 0 ? <ArrowUpRight className="w-3.5 h-3.5 text-emerald-600" /> : <ArrowDownRight className="w-3.5 h-3.5 text-rose-600" />}
            <span className={monthGrowthPct >= 0 ? 'text-emerald-600' : 'text-rose-600'}>{monthGrowthPct >= 0 ? '+' : ''}{monthGrowthPct}%</span>
            <span className="text-slate-400 font-normal">dari bulan lalu</span>
          </div>
        </div>

        <div onClick={() => onNavigateTab('master')} className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs hover:shadow-md transition-all cursor-pointer group">
          <div className="p-2.5 bg-slate-100 text-slate-700 rounded-xl w-fit"><Building2 className="w-5 h-5" /></div>
          <p className="mt-3 text-xs font-medium text-slate-500">Unit Kerja</p>
          <p className="text-3xl font-black text-slate-900">{totalUnit}</p>
          <p className="mt-1 text-xs text-slate-400">Jumlah unit terdaftar</p>
        </div>

        <div onClick={() => onNavigateTab('master')} className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs hover:shadow-md transition-all cursor-pointer group">
          <div className="p-2.5 bg-slate-100 text-slate-700 rounded-xl w-fit"><FolderKanban className="w-5 h-5" /></div>
          <p className="mt-3 text-xs font-medium text-slate-500">Kategori</p>
          <p className="text-3xl font-black text-slate-900">{totalKategori}</p>
          <p className="mt-1 text-xs text-slate-400">Kategori arsip</p>
        </div>

        <div onClick={() => onNavigateTab('recycle_bin')} className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs hover:shadow-md transition-all cursor-pointer group">
          <div className="p-2.5 bg-orange-50 text-orange-600 rounded-xl w-fit"><Trash2 className="w-5 h-5" /></div>
          <p className="mt-3 text-xs font-medium text-slate-500">Recycle Bin</p>
          <p className="text-3xl font-black text-slate-900">{deletedCount}</p>
          <p className="mt-1 text-xs text-slate-400">Arsip di recycle bin</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm">Arsip per Kategori</h3>
            <select value={categoryPeriodDays} onChange={(e) => setCategoryPeriodDays(Number(e.target.value))} className="text-xs font-medium border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500/20">
              {PERIOD_OPTIONS.map((opt) => (<option key={opt.value} value={opt.value}>{opt.label}</option>))}
            </select>
          </div>

          {categoryTotal === 0 ? (
            <p className="text-xs text-slate-400 py-10 text-center">Belum ada data arsip pada periode ini.</p>
          ) : (
            <div className="flex items-center gap-6 flex-wrap sm:flex-nowrap">
              <svg viewBox="0 0 180 180" className="w-40 h-40 shrink-0 -rotate-90">
                {donutSegments.map((seg) => (
                  <circle key={seg.name} cx="90" cy="90" r={donutRadius} fill="none" stroke={seg.color} strokeWidth="26" strokeDasharray={`${seg.dash} ${donutCircumference - seg.dash}`} strokeDashoffset={seg.offset} />
                ))}
                <circle cx="90" cy="90" r={donutRadius - 26} fill="white" />
                <text x="90" y="86" textAnchor="middle" className="fill-slate-900 font-black" fontSize="26" transform="rotate(90 90 90)">{categoryTotal}</text>
                <text x="90" y="106" textAnchor="middle" className="fill-slate-400 font-medium" fontSize="11" transform="rotate(90 90 90)">Total</text>
              </svg>

              <div className="flex-1 min-w-[180px] space-y-2">
                {categoryBreakdown.map((c) => (
                  <button key={c.name} onClick={() => onNavigateToArsipWithFilter(undefined, c.name === 'Lainnya' ? undefined : c.name)} className="w-full flex items-center justify-between text-xs hover:bg-slate-50 rounded-lg px-1.5 py-1 -mx-1.5 cursor-pointer">
                    <span className="flex items-center gap-2 text-slate-700 font-medium">
                      <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: c.color }} />
                      {c.name}
                    </span>
                    <span className="text-slate-500 font-mono">{c.count} ({c.pct}%)</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm">Arsip per Bulan</h3>
            <select value={selectedYear} onChange={(e) => setSelectedYear(Number(e.target.value))} className="text-xs font-medium border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500/20">
              {availableYears.map((y) => (<option key={y} value={y}>{y}</option>))}
            </select>
          </div>
          <div className="flex items-end justify-between gap-1.5 h-48 pt-4">
            {monthlyBreakdown.map((count, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center justify-end h-full gap-1.5 group">
                <span className="text-[10px] font-bold text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity">{count}</span>
                <div className="w-full max-w-[22px] bg-blue-600 rounded-t-md transition-all hover:bg-blue-500" style={{ height: `${Math.max(4, (count / monthlyMax) * 100)}%` }} />
                <span className="text-[10px] font-medium text-slate-500">{MONTH_LABELS[idx]}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs space-y-1">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-slate-900 text-sm">Arsip Terbaru</h3>
            <button onClick={() => onNavigateToArsipWithFilter('ALL')} className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer">
              <span>Lihat Semua</span><ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
          {recentItems.length === 0 ? (
            <p className="text-xs text-slate-400 py-8 text-center">Belum ada arsip yang ditambahkan.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentItems.map((item) => (
                <div key={item.id} className="py-3 flex items-center justify-between gap-3">
                  <button onClick={() => (item.pdfAttachment ? onOpenPdfModal(item) : onNavigateToArsipWithFilter('ALL'))} className="flex items-center gap-3 flex-1 min-w-0 text-left cursor-pointer group">
                    <span className="p-2 bg-rose-50 text-rose-600 rounded-lg shrink-0"><FileText className="w-4 h-4" /></span>
                    <span className="min-w-0">
                      <span className="block text-xs font-bold text-slate-900 truncate group-hover:text-blue-700">{item.perihal}</span>
                      <span className="block text-[11px] text-slate-500 truncate">{item.kategoriArsip || 'Lainnya'} · {item.unitPengolah || 'Umum'}</span>
                    </span>
                  </button>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-[11px] text-slate-400 hidden sm:block">{timeAgo(item.createdAt)}</span>
                    <button onClick={() => onOpenQrModal(item)} title="QR Code" className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer"><QrCode className="w-3.5 h-3.5" /></button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs space-y-1">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-slate-900 text-sm">Aktivitas Terbaru</h3>
            <button onClick={() => onNavigateTab('audit_log')} className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer">
              <Clock className="w-3.5 h-3.5" /><span>Riwayat Lengkap</span>
            </button>
          </div>
          {recentActivity.length === 0 ? (
            <p className="text-xs text-slate-400 py-8 text-center">Belum ada aktivitas tercatat.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentActivity.map((log) => {
                const meta = ACTION_META[log.action] || ACTION_META.UBAH;
                const Icon = meta.icon;
                return (
                  <div key={log.id} className="py-3 flex items-start gap-3">
                    <span className={`p-2 rounded-lg shrink-0 ${meta.bg} ${meta.fg}`}><Icon className="w-3.5 h-3.5" /></span>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs text-slate-800"><span className="font-bold">{log.userName}</span> <span className="text-slate-600">{meta.label}</span></p>
                      <p className="text-[11px] text-slate-500 truncate">{log.itemTarget && log.itemTarget !== '-' ? log.itemTarget : log.details}</p>
                    </div>
                    <span className="text-[10px] text-slate-400 shrink-0 whitespace-nowrap">{timeAgo(log.timestamp)}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
