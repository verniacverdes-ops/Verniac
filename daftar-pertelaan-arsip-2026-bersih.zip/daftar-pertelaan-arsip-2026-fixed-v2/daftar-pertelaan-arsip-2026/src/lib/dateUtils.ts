// Helper tanggal/waktu bersama. Dibuat supaya format tanggal konsisten di
// seluruh app dan supaya "X menit/jam yang lalu" (relative time) bisa
// dihitung dengan benar -- ini butuh timestamp ASLI (ISO 8601), bukan
// string yang sudah diformat duluan seperti "13/8/2026, 14.32.10" (format
// itu susah/rawan salah kalau di-parse ulang).
//
// Konvensi di seluruh app: `AuditLogEntry.timestamp` SELALU disimpan
// sebagai ISO string mentah di state. Formatnya untuk tampilan (baik
// format lengkap maupun relatif) dilakukan di titik render lewat dua
// fungsi ini, bukan saat data pertama kali diterima/dibuat.

/**
 * Format lengkap ala "13 Agu 2026, 14.32" untuk tabel/detail/CSV export.
 * Kalau input bukan tanggal valid (data lama sebelum konvensi ini berlaku,
 * atau field kosong), kembalikan apa adanya supaya tidak menampilkan
 * "Invalid Date".
 */
export function formatDateTime(isoOrRaw: string | undefined | null): string {
  if (!isoOrRaw) return '-';
  const d = new Date(isoOrRaw);
  if (isNaN(d.getTime())) return isoOrRaw;
  return d.toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' });
}

/**
 * Waktu relatif ala "5 menit yang lalu" / "2 jam yang lalu" / "3 hari yang
 * lalu". Untuk rentang lebih dari 7 hari, jatuh balik ke tanggal singkat
 * (mis. "6 Jan 2026") supaya tidak menampilkan angka hari yang terlalu besar
 * dan kurang informatif.
 */
export function timeAgo(isoOrRaw: string | undefined | null): string {
  if (!isoOrRaw) return '-';
  const d = new Date(isoOrRaw);
  if (isNaN(d.getTime())) return isoOrRaw;

  const diffMs = Date.now() - d.getTime();
  const diffSec = Math.floor(diffMs / 1000);

  if (diffSec < 0) return 'baru saja';
  if (diffSec < 60) return 'baru saja';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin} menit yang lalu`;
  const diffHour = Math.floor(diffMin / 60);
  if (diffHour < 24) return `${diffHour} jam yang lalu`;
  const diffDay = Math.floor(diffHour / 24);
  if (diffDay < 7) return `${diffDay} hari yang lalu`;

  return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
}
