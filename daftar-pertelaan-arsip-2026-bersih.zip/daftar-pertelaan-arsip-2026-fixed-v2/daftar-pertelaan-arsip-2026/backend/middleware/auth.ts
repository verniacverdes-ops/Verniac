// =====================================================================
// FASE 7: Middleware otentikasi & otorisasi berbasis peran (role) untuk
// endpoint Express. Dipakai oleh backend/routes/*.ts.
// =====================================================================
import type { Request, Response, NextFunction } from "express";
import { verifyToken, type AuthTokenPayload } from "../config/auth";

// Menambahkan field `user` ke tipe Request Express supaya route handler
// bisa membaca `req.user` dengan aman (typed) setelah middleware ini.
declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthTokenPayload;
    }
  }
}

/**
 * Mengambil token dari header `Authorization: Bearer <token>`, atau
 * (khusus dipakai untuk endpoint pratinjau dokumen yang di-embed lewat
 * <iframe>, yang tidak bisa menyisipkan header custom) dari query
 * string `?token=...`.
 */
function extractToken(req: Request): string | null {
  const header = req.headers.authorization;
  if (header && header.startsWith("Bearer ")) {
    return header.slice("Bearer ".length).trim();
  }
  if (typeof req.query.token === "string" && req.query.token) {
    return req.query.token;
  }
  return null;
}

/**
 * Mewajibkan request memiliki token JWT yang valid & belum kedaluwarsa.
 * Kalau valid, `req.user` diisi dengan payload token (id, username, role, name).
 */
export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const token = extractToken(req);

  if (!token) {
    return res.status(401).json({
      status: "error",
      message: "Otentikasi wajib. Sertakan header Authorization: Bearer <token>.",
    });
  }

  const payload = verifyToken(token);
  if (!payload) {
    return res.status(401).json({
      status: "error",
      message: "Token tidak valid atau sudah kedaluwarsa. Silakan login ulang.",
    });
  }

  req.user = payload;
  next();
}

/**
 * Seperti requireAuth, tapi tidak menolak request jika token tidak ada
 * / tidak valid — hanya mengisi req.user kalau tokennya sah. Cocok untuk
 * endpoint publik yang perilakunya sedikit berbeda kalau user login
 * (mis. GET dokumen PDF yang butuh audit "siapa yang membuka").
 */
export function optionalAuth(req: Request, _res: Response, next: NextFunction) {
  const token = extractToken(req);
  if (token) {
    const payload = verifyToken(token);
    if (payload) req.user = payload;
  }
  next();
}

/**
 * Membatasi endpoint hanya untuk peran (role) tertentu. Selalu pasang
 * requireAuth() SEBELUM requireRole(...) di rantai middleware.
 */
export function requireRole(...allowedRoles: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ status: "error", message: "Otentikasi wajib." });
    }
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        status: "error",
        message: `Peran "${req.user.role}" tidak memiliki hak akses untuk aksi ini.`,
      });
    }
    next();
  };
}
