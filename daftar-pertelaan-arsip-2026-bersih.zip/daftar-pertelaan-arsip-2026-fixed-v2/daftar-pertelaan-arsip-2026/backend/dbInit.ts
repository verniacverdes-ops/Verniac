// =====================================================================
// npm run db:init
//
// Yang dilakukan script ini:
//   1. Membaca database/daftar-pertelaan-arsip-2026.sql & menjalankan
//      tiap statement CREATE TABLE-nya lewat koneksi yang sama dengan
//      .env.local (jadi tidak perlu buka phpMyAdmin/CLI mysql manual).
//   2. Kalau tabel `users` masih kosong, mengisi 6 akun demo (satu per
//      peran, dari src/data/initialUsers.ts) dengan password AWAL
//      "password123" untuk SEMUA akun -- SAMA dengan yang dipakai tombol
//      "Simulasi Peran" di src/components/LoginModal.tsx. Ini HANYA
//      untuk demo/pengembangan lokal -- ganti semua password ini
//      sebelum dipakai di lingkungan produksi sungguhan.
// =====================================================================
import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";
import { pool, testConnection } from "../config/database";
import { hashPassword } from "../config/auth";
import { DEFAULT_USERS } from "../../src/data/initialUsers";
import crypto from "crypto";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SQL_PATH = path.resolve(__dirname, "..", "..", "database", "daftar-pertelaan-arsip-2026.sql");

/** Pisah file .sql jadi statement individual. Cukup sederhana (split by `;`)
 * karena schema kita sendiri tidak memakai DELIMITER/trigger/procedure. */
function splitStatements(sql: string): string[] {
  return sql
    .split(/;\s*(?:\r?\n|$)/g)
    .map((s) => s.trim())
    .filter((s) => s.length > 0 && !s.startsWith("--"));
}

async function runSchema() {
  const sql = await fs.readFile(SQL_PATH, "utf8");
  const statements = splitStatements(sql);
  console.log(`[db:init] Menjalankan ${statements.length} statement dari ${path.basename(SQL_PATH)}...`);
  for (const statement of statements) {
    await pool.query(statement);
  }
  console.log("[db:init] Skema (tabel arsip, master data, users, audit_logs, token_blacklist) siap.");
}

async function seedDemoUsers() {
  const [rows] = await pool.query<any[]>("SELECT COUNT(*) AS total FROM `users`");
  const total = rows[0]?.total ?? 0;

  if (total > 0) {
    console.log(`[db:init] Tabel users sudah berisi ${total} akun -- lewati seeding demo.`);
    return;
  }

  console.log("[db:init] Tabel users kosong, membuat akun demo (satu per peran)...");
  // Password SAMA untuk semua akun demo -- lihat catatan di header file
  // ini soal kenapa harus konsisten dengan LoginModal.tsx.
  const demoPassword = "password123";
  for (const user of DEFAULT_USERS) {
    const passwordHash = await hashPassword(demoPassword); // hashPassword itu async -- WAJIB di-await.
    await pool.query(
      `INSERT INTO \`users\`
        (id, name, username, email, password_hash, role, unit_kerja, avatar_url, is_active)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)`,
      [
        crypto.randomUUID(),
        user.name,
        user.username,
        user.email,
        passwordHash,
        user.role,
        user.unitKerja ?? null,
        user.avatarUrl ?? null,
      ]
    );
    console.log(`[db:init]   + ${user.username} / ${demoPassword}  (role: ${user.role})`);
  }
  console.log(
    "[db:init] Akun demo dibuat. PENTING: password semua akun demo = \"password123\" -- " +
      "wajib diganti sebelum sistem ini dipakai dengan data arsip sungguhan."
  );
}

async function main() {
  await runSchema();
  await seedDemoUsers();
  await testConnection();
  await pool.end();
  console.log("[db:init] Selesai.");
}

main().catch((err) => {
  console.error("[db:init] Gagal:", err);
  process.exit(1);
});